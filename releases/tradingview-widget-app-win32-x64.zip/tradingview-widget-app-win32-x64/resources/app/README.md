# **Tradingview Widget App**
### [Downloads](https://github.com/ug-code/tradingview-widget-app/tree/master/releases)


## Building & running it locally:
- Clone the repo.
- cd to the directory
- install and run with `npm install && npm start`

## Packaging it
-  For use from the CLI
- `npm install electron-packager -g`
- `electron-packager ./ --platform win32 --arch x64 --out releases/`

